package com.capstone.fashionboomerandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView ivImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivImage = findViewById(R.id.iv_image);

        // Glide로 이미지 표시하기
        String imageUrl = "http://fashionboomer.tk:8080/v11/closets/images/9";
        Glide.with(this).load(imageUrl).into(ivImage);
    }
}